import { useCallback, useEffect, useMemo, useRef, useState, type PointerEvent } from "react";
import {
  Aperture, ArrowLeft, Camera, Check, ChevronRight, CircleHelp, Download, Grid2X2,
  Heart, Home, ImagePlus, Images, Library, Menu, Minus, Plus, RotateCcw, Search,
  Settings, SlidersHorizontal, Sparkles, Trash2, Upload, Video, X, Wifi, WifiOff
} from "lucide-react";
import { clearImages, deleteImage, getImages, putImage, type StoredImage } from "./db";

type Pose = { id: string; title: string; category: string; image: string; description: string };
type Tab = "home" | "explore" | "camera" | "favourites" | "myposes" | "settings";
const photo = (id: string) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=900&q=85`;
const categories = [
  "Street","Cafe","Rooftop","Beach","Studio","Nature","Urban","Architecture","Park","Travel","Lifestyle",
  "Fashion","Seated","Standing","Walking","Portrait","Couples","Friends","Golden Hour","Night","Minimal","Creative"
];
const seeds: Pose[] = [
  ["p1","City stride","Street","photo-1517841905240-472988babdf9","A relaxed walking pose with natural movement."],
  ["p2","Cafe pause","Cafe","photo-1524504388940-b1c1722653e1","A seated lifestyle reference."],
  ["p3","Rooftop silhouette","Rooftop","photo-1534528741775-53994a69daeb","A clean portrait with open posture."],
  ["p4","Coastal stance","Beach","photo-1529139574466-a303027c1d8b","A full-body fashion-inspired stance."],
  ["p5","Soft portrait","Portrait","photo-1531123897727-8f129e1688ce","A simple portrait framing reference."],
  ["p6","Golden hour","Golden Hour","photo-1529626455594-4ff0802cfb7e","A warm outdoor portrait reference."],
  ["p7","Park movement","Park","photo-1508214751196-bcfd4ca60f91","An easy standing pose outdoors."],
  ["p8","Travel look","Travel","photo-1529139574466-a303027c1d8b","A travel editorial reference."],
  ["p9","Studio stance","Studio","photo-1534528741775-53994a69daeb","A clean studio-style pose."],
  ["p10","Urban wall","Urban","photo-1524504388940-b1c1722653e1","A casual urban pose."],
  ["p11","Nature pause","Nature","photo-1517841905240-472988babdf9","A natural relaxed pose."],
  ["p12","Fashion frame","Fashion","photo-1529139574466-a303027c1d8b","A fashion-oriented standing pose."]
].map(([id,title,category,img,description]) => ({id,title,category,image:photo(img),description}));
const categoryImages = [seeds[0].image,seeds[1].image,seeds[2].image,seeds[3].image];
const initialSettings = { opacity: 45, zoom: 100, grid: true, level: true, facing: "environment" as "environment"|"user", quality: 92 };

function App() {
  const [tab,setTab] = useState<Tab>("home");
  const [selected,setSelected] = useState<Pose|null>(null);
  const [search,setSearch] = useState("");
  const [activeCategory,setActiveCategory] = useState("All");
  const [favourites,setFavourites] = useState<string[]>(() => JSON.parse(localStorage.getItem("ps-favs")||"[]"));
  const [recent,setRecent] = useState<string[]>(() => JSON.parse(localStorage.getItem("ps-recent")||"[]"));
  const [personal,setPersonal] = useState<StoredImage[]>([]);
  const [settings,setSettings] = useState(() => ({...initialSettings,...JSON.parse(localStorage.getItem("ps-settings")||"{}")}));
  const [online,setOnline] = useState(navigator.onLine);
  const [notice,setNotice] = useState("");
  const [captured,setCaptured] = useState<string|null>(null);
  const [cameraError,setCameraError] = useState("");
  const [cameraActive,setCameraActive] = useState(false);
  const [level,setLevel] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream|null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [overlay,setOverlay] = useState({x:50,y:50,scale:1});
  const pointers = useRef(new Map<number,{x:number,y:number}>());
  const gesture = useRef<{distance:number;scale:number;x:number;y:number;cx:number;cy:number}|null>(null);

  const poses = useMemo(() => [...seeds,...personal.map(p=>({id:p.id,title:p.name,category:"My Poses",image:p.dataUrl,description:"Personal reference imported from this device."}))],[personal]);
  const filtered = useMemo(() => poses.filter(p =>
    (activeCategory==="All" || p.category===activeCategory) &&
    `${p.title} ${p.category} ${p.description}`.toLowerCase().includes(search.toLowerCase())
  ),[poses,activeCategory,search]);

  const flash = (message:string) => { setNotice(message); window.setTimeout(()=>setNotice(""),2600); };
  useEffect(()=>{ localStorage.setItem("ps-favs",JSON.stringify(favourites)); },[favourites]);
  useEffect(()=>{ localStorage.setItem("ps-recent",JSON.stringify(recent)); },[recent]);
  useEffect(()=>{ localStorage.setItem("ps-settings",JSON.stringify(settings)); },[settings]);
  useEffect(()=>{ getImages().then(setPersonal).catch(()=>flash("Local image storage is unavailable in this browser.")); },[]);
  useEffect(()=>{
    const on=()=>setOnline(true), off=()=>setOnline(false);
    window.addEventListener("online",on); window.addEventListener("offline",off);
    return ()=>{window.removeEventListener("online",on);window.removeEventListener("offline",off);};
  },[]);
  const stopCamera = useCallback(()=>{ streamRef.current?.getTracks().forEach(t=>t.stop()); streamRef.current=null; setCameraActive(false); },[]);
  const startCamera = useCallback(async()=>{
    setCameraError("");
    if (!navigator.mediaDevices?.getUserMedia) { setCameraError("Camera access needs HTTPS or localhost and a supported browser."); return; }
    try {
      stopCamera();
      const stream=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:{ideal:settings.facing},width:{ideal:1920},height:{ideal:1080}}});
      streamRef.current=stream;
      if(videoRef.current){videoRef.current.srcObject=stream; await videoRef.current.play();}
      setCameraActive(true);
    } catch(e) {
      const err=e as DOMException;
      setCameraError(err.name==="NotAllowedError"?"Camera permission was denied. Allow camera access in browser settings and retry.":err.name==="NotFoundError"?"No camera was found on this device.":"Unable to start camera. Check permissions and whether another app is using it.");
    }
  },[settings.facing,stopCamera]);
  useEffect(()=>{ if(tab==="camera" && !captured) startCamera(); else stopCamera(); return ()=>stopCamera(); },[tab,captured,startCamera,stopCamera]);
  const choosePose=(pose:Pose)=>{setSelected(pose);setRecent(r=>[pose.id,...r.filter(x=>x!==pose.id)].slice(0,12));setOverlay({x:50,y:50,scale:1});setCaptured(null);setTab("camera");};
  const toggleFavourite=(id:string)=>setFavourites(f=>f.includes(id)?f.filter(x=>x!==id):[...f,id]);
  const updateSetting=(key:keyof typeof initialSettings,value:any)=>setSettings((s:any)=>({...s,[key]:value}));

  const capture=()=>{
    const video=videoRef.current, canvas=canvasRef.current;
    if(!video || !canvas || !video.videoWidth){flash("Camera is not ready yet.");return;}
    canvas.width=video.videoWidth; canvas.height=video.videoHeight;
    const ctx=canvas.getContext("2d");
    if(!ctx)return;
    // Draw only the video frame. The DOM reference overlay and controls are intentionally excluded.
    const mirrored=settings.facing==="user";
    if(mirrored){ctx.translate(canvas.width,0);ctx.scale(-1,1);}
    ctx.drawImage(video,0,0,canvas.width,canvas.height);
    canvas.toBlob(blob=>{
      if(!blob){flash("Could not create photograph.");return;}
      const url=URL.createObjectURL(blob);setCaptured(url);stopCamera();
    },"image/jpeg",settings.quality/100);
  };
  const saveCapture=()=>{
    if(!captured)return;
    const a=document.createElement("a");a.href=captured;a.download=`pose-studio-${Date.now()}.jpg`;a.click();
    flash("Photograph saved to your downloads.");
  };
  const importFiles=async(files:FileList|null)=>{
    if(!files)return;
    for(const file of Array.from(files)){
      if(!file.type.startsWith("image/"))continue;
      const dataUrl=await new Promise<string>((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result));r.onerror=()=>reject(r.error);r.readAsDataURL(file);});
      const item={id:`local-${crypto.randomUUID()}`,name:file.name.replace(/\.[^.]+$/,""),dataUrl,createdAt:Date.now()};
      try{await putImage(item);setPersonal(p=>[item,...p]);}catch{flash("Could not store image. Device storage may be full.");}
    }
    flash("Personal reference imported.");
  };
  const removePersonal=async(id:string)=>{await deleteImage(id);setPersonal(p=>p.filter(x=>x.id!==id));setFavourites(f=>f.filter(x=>x!==id));};
  const clearAll=async()=>{if(!confirm("Delete all imported references and favourites from this device?"))return;await clearImages();setPersonal([]);setFavourites([]);setRecent([]);localStorage.removeItem("ps-favs");localStorage.removeItem("ps-recent");flash("Local data cleared.");};
  const openCameraFor=(p:Pose|null)=>{setSelected(p);setCaptured(null);setTab("camera");};

  const poseCard=(p:Pose)=> <article className="pose-card" key={p.id}>
    <button className="image-button" onClick={()=>choosePose(p)} aria-label={`Use ${p.title}`}><img src={p.image} loading="lazy" alt={p.title}/><span className="use-chip">Use pose <ChevronRight size={14}/></span></button>
    <div className="card-meta"><div><strong>{p.title}</strong><small>{p.category}</small></div><button className={`icon-btn ${favourites.includes(p.id)?"liked":""}`} onClick={()=>toggleFavourite(p.id)} aria-label="Toggle favourite"><Heart size={18} fill={favourites.includes(p.id)?"currentColor":"none"}/></button></div>
  </article>;

  const cameraScreen=()=> <section className="camera-screen">
    <div className="camera-top"><button className="icon-btn" onClick={()=>setTab("explore")}><ArrowLeft/></button><div><strong>Pose camera</strong><small>{selected?.title||"Choose a reference"}</small></div><button className="icon-btn" onClick={()=>updateSetting("facing",settings.facing==="user"?"environment":"user")}><RotateCcw/></button></div>
    <div className="viewfinder" onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onPointerCancel={onPointerUp}>
      {captured ? <img className="captured-preview" src={captured} alt="Captured photograph preview"/> :
        <><video ref={videoRef} autoPlay playsInline muted className={settings.facing==="user"?"mirrored":""}/>
        {selected && <img className="reference-overlay" src={selected.image} alt="Pose reference overlay" draggable={false} style={{left:`${overlay.x}%`,top:`${overlay.y}%`,opacity:settings.opacity/100,transform:`translate(-50%,-50%) scale(${overlay.scale*settings.zoom/100})`}}/>}
        {settings.grid && <div className="grid-overlay"><i/><i/><i/><i/></div>}
        {settings.level && <div className="level-line" style={{transform:`translate(-50%,-50%) rotate(${level}deg)`}}><span/></div>}
        {!cameraActive && !cameraError && <div className="camera-loading"><Aperture size={34}/><span>Starting camera…</span></div>}
        {cameraError && <div className="camera-error"><Camera size={34}/><strong>Camera unavailable</strong><p>{cameraError}</p><button className="primary-btn" onClick={startCamera}>Try again</button></div>}
        </>}
      <div className="viewfinder-hint">{selected?"Drag reference to reposition · pinch or scroll to resize":"Select a pose from Explore or import your own"}</div>
    </div>
    {captured ? <div className="capture-actions"><button className="secondary-btn" onClick={()=>{URL.revokeObjectURL(captured);setCaptured(null);}}>Retake</button><button className="primary-btn" onClick={saveCapture}><Download size={17}/> Save photo</button></div> :
    <><div className="camera-controls">
      <div className="control-row"><label>Opacity <b>{settings.opacity}%</b></label><input type="range" min="0" max="100" value={settings.opacity} onChange={e=>updateSetting("opacity",+e.target.value)}/></div>
      <div className="control-row"><label>Zoom <b>{settings.zoom}%</b></label><input type="range" min="25" max="250" value={settings.zoom} onChange={e=>updateSetting("zoom",+e.target.value)}/></div>
      <div className="tool-row"><button className={`tool ${settings.grid?"active":""}`} onClick={()=>updateSetting("grid",!settings.grid)}><Grid2X2 size={17}/> Grid</button><button className={`tool ${settings.level?"active":""}`} onClick={()=>updateSetting("level",!settings.level)}><SlidersHorizontal size={17}/> Level</button><button className="tool" onClick={()=>setOverlay({x:50,y:50,scale:1})}><RotateCcw size={17}/> Reset</button><button className="tool" onClick={()=>setSelected(null)}><X size={17}/> Hide pose</button></div>
    </div><div className="shutter-row"><button className="gallery-shortcut" onClick={()=>fileRef.current?.click()}><ImagePlus/></button><button className="shutter" onClick={capture} disabled={!cameraActive}><span/></button><button className="gallery-shortcut" onClick={()=>updateSetting("facing",settings.facing==="user"?"environment":"user")}><RotateCcw/></button></div></>}
    <canvas ref={canvasRef} className="hidden-canvas"/>
  </section>;

  function onPointerDown(e:PointerEvent<HTMLDivElement>){
    if(!selected || captured)return;
    e.currentTarget.setPointerCapture(e.pointerId);
    pointers.current.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(pointers.current.size===1)gesture.current={distance:0,scale:overlay.scale,x:overlay.x,y:overlay.y,cx:e.clientX,cy:e.clientY};
    if(pointers.current.size===2){const pts=[...pointers.current.values()];gesture.current={distance:Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y),scale:overlay.scale,x:overlay.x,y:overlay.y,cx:(pts[0].x+pts[1].x)/2,cy:(pts[0].y+pts[1].y)/2};}
  }
  function onPointerMove(e:PointerEvent<HTMLDivElement>){
    if(!pointers.current.has(e.pointerId)||!gesture.current)return;
    pointers.current.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rect=e.currentTarget.getBoundingClientRect();
    if(pointers.current.size===1){setOverlay(o=>({...o,x:Math.max(0,Math.min(100,gesture.current!.x+(e.clientX-gesture.current!.cx)/rect.width*100)),y:Math.max(0,Math.min(100,gesture.current!.y+(e.clientY-gesture.current!.cy)/rect.height*100))}));}
    if(pointers.current.size===2){const pts=[...pointers.current.values()];const d=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);const base=gesture.current.distance||d;setOverlay(o=>({...o,scale:Math.max(.25,Math.min(2.5,gesture.current!.scale*d/base))}));}
  }
  function onPointerUp(e:PointerEvent<HTMLDivElement>){pointers.current.delete(e.pointerId);if(pointers.current.size===0)gesture.current=null;}
  useEffect(()=>{
    const el=document.querySelector(".viewfinder");
    const wheel=(event:Event)=>{const e=event as WheelEvent;if(tab==="camera"&&selected&&!captured){e.preventDefault();setOverlay(o=>({...o,scale:Math.max(.25,Math.min(2.5,o.scale*(e.deltaY>0?.95:1.05)))}));}};
    el?.addEventListener("wheel",wheel,{passive:false});return()=>el?.removeEventListener("wheel",wheel);
  },[tab,selected,captured]);

  const header=(title:string,sub:string)=><div className="page-heading"><div><span className="eyebrow">POSE STUDIO</span><h1>{title}</h1><p>{sub}</p></div><div className="online-pill">{online?<Wifi size={14}/>:<WifiOff size={14}/>} {online?"Online":"Offline"}</div></div>;
  const home=<>{header("Find your frame.","Pose references for the photograph you have in mind.")}<div className="hero"><div><span className="eyebrow">YOUR CAMERA, YOUR COMPOSITION</span><h2>Match the pose.<br/>Make it yours.</h2><p>Use a reference over your live camera and find the frame.</p><button className="primary-btn" onClick={()=>setTab("explore")}>Explore poses <ChevronRight size={17}/></button></div><div className="hero-art"><img src={seeds[3].image} alt="Featured pose"/></div></div><div className="section-title"><h2>Explore by place</h2><button onClick={()=>setTab("explore")}>See all <ChevronRight size={15}/></button></div><div className="category-grid">{categories.slice(0,8).map((c,i)=><button className="category-tile" key={c} onClick={()=>{setActiveCategory(c);setTab("explore");}}><img src={categoryImages[i%4]} alt=""/><span>{c}</span></button>)}</div><div className="section-title"><h2>Recently viewed</h2></div><div className="pose-grid">{poses.filter(p=>recent.includes(p.id)).slice(0,4).map(poseCard)}{recent.length===0&&<p className="muted">Your recent references will appear here.</p>}</div></>;
  const explore=<>{header("Explore poses.","Browse the starter reference set or add your own images.")}<div className="search-box"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search poses or categories…"/>{search&&<button onClick={()=>setSearch("")}><X size={16}/></button>}</div><div className="category-pills"><button className={activeCategory==="All"?"selected":""} onClick={()=>setActiveCategory("All")}>All</button>{categories.map(c=><button key={c} className={activeCategory===c?"selected":""} onClick={()=>setActiveCategory(c)}>{c}</button>)}</div><div className="section-title"><h2>{activeCategory==="All"?"All references":activeCategory}</h2><span>{filtered.length} starter references</span></div><div className="pose-grid">{filtered.map(poseCard)}{filtered.length===0&&<div className="empty"><Images size={28}/><strong>No matches</strong><p>Try another search or category.</p></div>}</div><p className="disclaimer">Starter demo library: these sample references are remotely hosted photography. They are not the original Poseful catalogue.</p></>;
  const favs=<>{header("Favourites.","Your saved pose references.")}<div className="pose-grid">{poses.filter(p=>favourites.includes(p.id)).map(poseCard)}{favourites.length===0&&<div className="empty"><Heart size={28}/><strong>No favourites yet</strong><p>Tap the heart on any pose to save it here.</p></div>}</div></>;
  const myposes=<>{header("My poses.","Private reference images stored on this device.")}<button className="upload-panel" onClick={()=>fileRef.current?.click()}><Upload size={24}/><strong>Import reference photos</strong><span>Choose JPG, PNG or other browser-supported image files</span></button><input ref={fileRef} hidden type="file" accept="image/*" multiple onChange={e=>importFiles(e.target.files)}/><div className="section-title"><h2>Personal library</h2><span>{personal.length} images</span></div><div className="pose-grid">{poses.filter(p=>p.category==="My Poses").map(p=><article className="pose-card" key={p.id}><button className="image-button" onClick={()=>choosePose(p)}><img src={p.image} alt={p.title}/><span className="use-chip">Use pose <ChevronRight size={14}/></span></button><div className="card-meta"><div><strong>{p.title}</strong><small>On this device</small></div><button className="icon-btn danger" onClick={()=>removePersonal(p.id)}><Trash2 size={17}/></button></div></article>)}</div>{personal.length===0&&<p className="muted">No personal references imported yet.</p>}</>;
  const settingsPage=<>{header("Settings.","Tune your default camera workspace.")}<div className="settings-list">
    <div className="setting"><div><strong>Default overlay opacity</strong><small>Initial transparency for a new session</small></div><input type="range" min="0" max="100" value={settings.opacity} onChange={e=>updateSetting("opacity",+e.target.value)}/><b>{settings.opacity}%</b></div>
    <div className="setting"><div><strong>Default zoom</strong><small>Reference image scale</small></div><input type="range" min="25" max="250" value={settings.zoom} onChange={e=>updateSetting("zoom",+e.target.value)}/><b>{settings.zoom}%</b></div>
    <div className="setting"><div><strong>Composition grid</strong><small>Rule-of-thirds guides in camera</small></div><input type="checkbox" checked={settings.grid} onChange={e=>updateSetting("grid",e.target.checked)}/></div>
    <div className="setting"><div><strong>Level guide</strong><small>Horizontal alignment guide</small></div><input type="checkbox" checked={settings.level} onChange={e=>updateSetting("level",e.target.checked)}/></div>
    <div className="setting"><div><strong>Preferred camera</strong><small>Camera selected when available</small></div><select value={settings.facing} onChange={e=>updateSetting("facing",e.target.value)}><option value="environment">Rear camera</option><option value="user">Front camera</option></select></div>
    <div className="setting"><div><strong>Photo quality</strong><small>JPEG export quality</small></div><input type="range" min="60" max="100" value={settings.quality} onChange={e=>updateSetting("quality",+e.target.value)}/><b>{settings.quality}%</b></div>
  </div><div className="privacy-card"><strong>Privacy & storage</strong><p>Imported references and preferences are stored in this browser on this device. Camera video is not uploaded by this application.</p><button className="danger-btn" onClick={clearAll}>Clear local data</button></div></>;
  const tabs=[["home",Home,"Home"],["explore",Search,"Explore"],["camera",Camera,"Camera"],["favourites",Heart,"Saved"],["myposes",Library,"My poses"]] as const;
  return <div className="app-shell">
    <aside className="sidebar"><div className="brand"><div className="brand-mark"><Aperture/></div><div><strong>POSE STUDIO</strong><small>REFERENCE CAMERA</small></div></div><nav>{tabs.map(([id,Icon,label])=><button key={id} className={tab===id?"nav-active":""} onClick={()=>{setTab(id);if(id==="camera")setCaptured(null);}}><Icon size={19}/>{label}</button>)}</nav><button className="side-settings" onClick={()=>setTab("settings")}><Settings size={18}/> Settings</button><div className="sidebar-foot">A private creative workspace.</div></aside>
    <main className={`main-content ${tab==="camera"?"camera-main":""}`}>
      {tab==="home"&&home}{tab==="explore"&&explore}{tab==="camera"&&cameraScreen()}{tab==="favourites"&&favs}{tab==="myposes"&&myposes}{tab==="settings"&&settingsPage}
    </main>
    <nav className="mobile-nav">{tabs.map(([id,Icon,label])=><button key={id} className={tab===id?"nav-active":""} onClick={()=>{setTab(id);if(id==="camera")setCaptured(null);}}><Icon size={19}/><span>{label}</span></button>)}</nav>
    {notice&&<div className="toast">{notice}</div>}
  </div>;
}
export default App;