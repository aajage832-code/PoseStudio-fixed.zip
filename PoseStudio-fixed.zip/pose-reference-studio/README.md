# Pose Studio

A browser-based pose-reference and camera-overlay application inspired by publicly described pose-reference workflows. It is an independent implementation and is not affiliated with Poseful or Mind Start Technologies.

## Requirements
- Node.js 20+ recommended
- npm
- A modern browser
- Camera access requires `https://` or `http://localhost`

## Run locally
```bash
npm install
npm run dev
```
Open the URL printed by Vite (normally `http://localhost:5173`).

## Production build
```bash
npm run build
npm run preview
```

## Installable PWA
The manifest includes 192px and 512px icons. Deploy the production build over HTTPS, open the public URL in Android Chrome, then use the three-dot menu and choose **Install app** or **Add to Home screen**. Chrome's install offer depends on browser criteria and may take a little time to appear.

## Features implemented
- Responsive home, explore, camera, favourites, personal library and settings screens
- Search and 22 starter category filters
- Demo reference set (not the original Poseful library)
- Real browser camera using `getUserMedia`
- Front/rear camera preference and switching
- Draggable pose overlay; pinch-to-scale on touch; mouse-wheel scaling on desktop
- Opacity and zoom sliders, reset, hide, grid
- Capture from the video element into canvas; overlay and UI are not drawn into saved output
- Capture preview, retake and JPEG download
- Personal image import persisted in IndexedDB
- Favourites, recent items and preferences persisted locally
- Basic PWA manifest and service worker shell caching

## Important implementation notes / limitations
1. The starter library uses remote Unsplash-hosted sample photographs. They are demo references, not a licensed one-million-image catalogue and not verified Poseful content. Replace them with images you have rights to use for production.
2. The 22 category filters include four category names visible in the supplied reference and eighteen clearly illustrative starter categories. They are not claimed to match the original app's full category list.
3. The level control currently provides a visual horizontal guide, not sensor-derived horizon leveling. Browser/device orientation support varies; a calibrated device-orientation implementation would require permission handling and device-specific testing.
4. Offline support caches the app shell. Remote demo photos are not guaranteed offline. User-imported images and settings remain in IndexedDB/local storage.
5. Camera switching requests the newly preferred facing mode. Device/browser support varies, and some devices expose only one camera.
6. Browser security requires localhost or HTTPS. The application does not upload camera frames; capture is performed locally.
7. No physical-device camera test can be asserted from source generation alone. Test on the target Android device after granting permission.

## Suggested next steps
- Add a locally bundled, properly licensed reference pack.
- Implement a true device-orientation level with `DeviceOrientationEvent` permission flow where supported.
- Add Playwright browser tests and run them against a real HTTPS deployment and physical Android device.
- Add an image-provider integration only after reviewing its licensing and API terms.
